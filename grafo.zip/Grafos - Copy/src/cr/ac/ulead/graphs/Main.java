package cr.ac.ulead.graphs;

import cr.ac.ulead.algorithms.BreadthFirstSearch;
import cr.ac.ulead.algorithms.DeepFirstSearch;
import cr.ac.ulead.graphs.entities.Graph;


public class Main {

    private static Graph graph;

    public static void main(String[] args) {
	    buildGraph();
        DeepFirstSearch.runDF(graph,0);
        BreadthFirstSearch.runBF(graph,0);
    }

    private static void buildGraph() {
        graph = new Graph(false);
        graph.insert(0, 2);
        graph.insert(0,5);
        graph.insert(0, 7);
        graph.insert(1,7);
        graph.insert(2, 6);
        graph.insert(6,4);
        graph.insert(4, 3);
        graph.insert(5,3);
        graph.insert(5,4);
        graph.insert(7,4);
        graph.insert(8, 6);
    }




}
