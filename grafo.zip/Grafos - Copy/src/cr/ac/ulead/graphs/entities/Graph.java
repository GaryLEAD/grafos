package cr.ac.ulead.graphs.entities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Graph {

    private boolean directed;
    HashMap<Integer, List<Integer>> adjacent;

    public Graph(boolean directed) {
        this.directed = directed;
        this.adjacent = new HashMap<>();
    }

    public void insert(int v, int w){
        if (!this.adjacent.containsKey(v)) {
            this.adjacent.put(v, new ArrayList<>());
        }
        adjacent.get(v).add(w);
        if (!directed){
            if (!this.adjacent.containsKey(w)) {
                this.adjacent.put(w, new ArrayList<>());
            }
            adjacent.get(w).add(v);
        }
    }

    public void remove(int v, int w) {
        adjacent.get(v).remove(w);
        if (!directed){
            adjacent.get(w).remove(v);
        }
    }

    public boolean isDirected() { return this.directed;}

    public List<Integer> getNodes() {
        return new ArrayList<>(this.adjacent.keySet());
    }

    public List<Integer> getEdges(int v){
        return this.adjacent.get(v);
    }

    public int getEdgesQuantity(){ return this.adjacent.keySet().size();}

}
