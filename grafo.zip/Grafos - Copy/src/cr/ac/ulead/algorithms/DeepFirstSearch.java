package cr.ac.ulead.algorithms;

import cr.ac.ulead.graphs.entities.Graph;

import java.util.Arrays;
import java.util.List;

public class DeepFirstSearch {

    private static int cnt = 0;
    private static int[] ord;

    public static void runDF(Graph graph, int v) {
        int cnt = 0;
        ord = new int[graph.getNodes().size()];
        for (int i = 0; i < graph.getEdgesQuantity();i++){
            ord[i] = -1;
        }
        searchDF(v, ord, graph);
        System.out.println(Arrays.toString(ord));
    }

    private static void searchDF(int v, int[] indexes, Graph graph) {
        ord[v]  = cnt++;
        List<Integer> edges = graph.getEdges(v);
        for (Integer edge: edges) {
            if (ord[edge.intValue()] == -1) {
                searchDF(edge.intValue(),indexes,graph);
            }
        }
    }

}
