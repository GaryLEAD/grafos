package cr.ac.ulead.algorithms;

import cr.ac.ulead.graphs.entities.Graph;

import java.util.Arrays;
import java.util.List;

public class BreadthFirstSearch {
    private static int[] ord;

    public static void runBF(Graph graph, int v) {
        int cnt = 0;
        ord = new int[graph.getNodes().size()];
        for (int i = 0; i < graph.getEdgesQuantity();i++){
            ord[i] = -1;
        }
        searchBD(0, v, graph);
        System.out.println(Arrays.toString(ord));
    }

    private static void searchBD(int level, int v,  Graph graph){
        ord[v]  = level;
        List<Integer> edges = graph.getEdges(v);
        for (Integer edge: edges) {
            if (ord[edge.intValue()] == -1 ) {
                ord[edge.intValue()] = level+1;
            }
        }
        for (Integer edge: edges) {
            if (ord[edge.intValue()] == level+1) {
                searchBD(level + 1, edge.intValue(), graph);
            }
        }

    }
}